﻿/*
AutoHotkey

Copyright 2003-2009 Chris Mallett (support@autohotkey.com)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/

#include "stdafx.h" // pre-compiled headers
#include "clipboard.h"
#include "globaldata.h"  // for g_script.ScriptError() and g_ClipboardTimeout
#include "application.h" // for MsgSleep()
#include "util.h" // for strlcpy()

size_t Clipboard::Get(LPTSTR aBuf)
// If aBuf is NULL, it returns the length of the text on the clipboard and leaves the
// clipboard open.  Otherwise, it copies the clipboard text into aBuf and closes
// the clipboard.  In both cases, the length of the clipboard text is returned
// (or the value CLIPBOARD_FAILURE if error).  Caller must Close() the clipboard
// if aborting after calling Get(nullptr).
{
	// Seems best to always have done this even if we return early due to failure:
	if (aBuf)
		// It should be safe to do this even at its peak capacity, because caller
		// would have then given us the last char in the buffer, which is already
		// a zero terminator, so this would have no effect:
		*aBuf = '\0';

	UINT i, file_count = 0;
	BOOL clipboard_contains_text = IsClipboardFormatAvailable(CF_NATIVETEXT);
	BOOL clipboard_contains_files = IsClipboardFormatAvailable(CF_HDROP);
	if (!(clipboard_contains_text || clipboard_contains_files))
		return 0;

	if (!mIsOpen)
	{
		// As a precaution, don't give the caller anything from the clipboard
		// if the clipboard isn't already open from the caller's previous
		// call to determine the size of what's on the clipboard (no other app
		// can alter its size while we have it open).  The is to prevent a
		// buffer overflow from happening in a scenario such as the following:
		// Caller calls us and we return zero size, either because there's no
		// CF_TEXT on the clipboard or there was a problem opening the clipboard.
		// In these two cases, the clipboard isn't open, so by the time the
		// caller calls us again, there's a chance (vanishingly small perhaps)
		// that another app (if our thread were preempted long enough, or the
		// platform is multiprocessor) will have changed the contents of the
		// clipboard to something larger than zero.  Thus, if we copy that
		// into the caller's buffer, the buffer might overflow:
		if (aBuf)
			return 0;
		if (!Open())
		{
			// Since this should be very rare, a shorter message is now used.  Formerly, it was
			// "Could not open clipboard for reading after many timed attempts. Another program is probably holding it open."
			return Close(CANT_OPEN_CLIPBOARD_READ) ? 0 : CLIPBOARD_FAILURE;
		}
		if (   !(mClipMemNow = GetClipboardDataTimeout(clipboard_contains_text ? CF_NATIVETEXT : CF_HDROP))   )
		{
			// v2.0.18: Always tolerate NULL return from GetClipboardData.  Although it is difficult to see how
			// CF_TEXT might fail to be retrieved, a NULL return can be the result of the source app doing the
			// wrong thing; i.e. setting a NULL handle and failing to respond to WM_RENDERFORMAT correctly.
			// Because most apps would likely not report any failure of GetClipboardData, this "violation of
			// the contract" would go unnoticed in normal use.
			Close();
			if (aBuf)
				*aBuf = '\0';
			return 0;
		}
		// Although GlobalSize(mClipMemNow) can yield zero in some cases -- in which case GlobalLock() should
		// not be attempted -- it probably can't yield zero for CF_HDROP and CF_TEXT because such a thing has
		// never been reported by anyone.  Therefore, GlobalSize() is currently not called.
		if (   !(mClipMemNowLocked = (LPTSTR)GlobalLock(mClipMemNow))   )
		{
			return Close(_T("GlobalLock")) ? 0 : CLIPBOARD_FAILURE;  // Short error message since so rare.
		}
		// Otherwise: Update length after every successful new open&lock:
		// Determine the length (size - 1) of the buffer than would be
		// needed to hold what's on the clipboard:
		if (clipboard_contains_text)
		{
			// See below for comments.
			mLength = _tcslen(mClipMemNowLocked);
		}
		else // clipboard_contains_files
		{
			if (file_count = DragQueryFile((HDROP)mClipMemNowLocked, 0xFFFFFFFF, _T(""), 0))
			{
				mLength = (file_count - 1) * 2;  // Init; -1 if don't want a newline after last file.
				for (i = 0; i < file_count; ++i)
					mLength += DragQueryFile((HDROP)mClipMemNowLocked, i, NULL, 0);
			}
			else
				mLength = 0;
		}
		if (mLength >= CLIPBOARD_FAILURE) // Can't realistically happen, so just indicate silent failure.
			return CLIPBOARD_FAILURE;
	}
	if (!aBuf)
		return mLength;
		// Above: Just return the length; don't close the clipboard because we expect
		// to be called again soon.  Otherwise, caller must ensure Close() is called.
		// It's done this way to avoid the chance that the clipboard contents (and thus
		// its length) will change while we don't have it open, possibly resulting in a
		// buffer overflow.

	// Otherwise:
	if (clipboard_contains_text) // Fixed for v1.1.16.02: Prefer text over files if both are present.
	{
		// Because the clipboard is being retrieved as text, return this text even if
		// the clipboard also contains files.
		_tcscpy(aBuf, mClipMemNowLocked);  // Caller has already ensured that aBuf is large enough.
	}
	else // clipboard_contains_files
	{
		if (file_count = DragQueryFile((HDROP)mClipMemNowLocked, 0xFFFFFFFF, _T(""), 0))
			for (i = 0; i < file_count; ++i)
			{
				// Caller has already ensured aBuf is large enough to hold them all:
				aBuf += DragQueryFile((HDROP)mClipMemNowLocked, i, aBuf, 999);
				if (i < file_count - 1) // i.e. don't add newline after the last filename.
				{
					*aBuf++ = '\r';  // These two are the proper newline sequence that the OS prefers.
					*aBuf++ = '\n';
				}
				//else DragQueryFile() has ensured that aBuf is terminated.
			}
		// else aBuf has already been terminated upon entrance to this function.
	}
	Close();
	return mLength;
}



ResultType Clipboard::Set(LPCTSTR aBuf, UINT_PTR aLength)
// Returns OK or FAIL.
{
	// It was already open for writing from a prior call.  Return failure because callers that do this
	// are probably handling things wrong:
	if (IsReadyForWrite()) return FAIL;

	if (!aBuf)
	{
		aBuf = _T("");
		aLength = 0;
	}
	else
		if (aLength == UINT_MAX) // Caller wants us to determine the length.
			aLength = (UINT)_tcslen(aBuf);

	if (aLength)
	{
		if (!PrepareForWrite(aLength + 1))
			return FAIL;  // It already displayed the error.
		tcslcpy(mClipMemNewLocked, aBuf, aLength + 1);  // Copy only a substring, if aLength specifies such.
	}
	// else just do the below to empty the clipboard, which is different than setting
	// the clipboard equal to the empty string: it's not truly empty then, as reported
	// by IsClipboardFormatAvailable(CF_TEXT) -- and we want to be able to make it truly
	// empty for use with functions such as ClipWait:
	return Commit();  // It will display any errors.
}



LPTSTR Clipboard::PrepareForWrite(size_t aAllocSize)
{
	if (!aAllocSize) return NULL; // Caller should ensure that size is at least 1, i.e. room for the zero terminator.
	if (IsReadyForWrite())
		// It was already prepared due to a prior call.  Currently, the most useful thing to do
		// here is return the memory area that's already been reserved:
		return mClipMemNewLocked;
	// Note: I think GMEM_DDESHARE is recommended in addition to the usual GMEM_MOVEABLE:
	// UPDATE: MSDN: "The following values are obsolete, but are provided for compatibility
	// with 16-bit Windows. They are ignored.": GMEM_DDESHARE
	if (   !(mClipMemNew = GlobalAlloc(GMEM_MOVEABLE, aAllocSize * sizeof(TCHAR)))   )
	{
		MemoryError();
		return NULL;
	}
	if (   !(mClipMemNewLocked = (LPTSTR)GlobalLock(mClipMemNew))   )
	{
		mClipMemNew = GlobalFree(mClipMemNew);  // This keeps mClipMemNew in sync with its state.
		g_script.RuntimeError(ERR_INTERNAL_CALL, _T(""), FAIL);  // Generic error message since so rare.
		return NULL;
	}
	mCapacity = (UINT)aAllocSize; // Keep mCapacity in sync with the state of mClipMemNewLocked.
	*mClipMemNewLocked = '\0'; // Init for caller.
	return mClipMemNewLocked;  // The caller can now write to this mem.
}



ResultType Clipboard::Commit(UINT aFormat)
// If this is called while mClipMemNew is NULL, the clipboard will be set to be truly
// empty, which is different from writing an empty string to it.  Note: If the clipboard
// was already physically open, this function will close it as part of the commit (since
// whoever had it open before can't use the prior contents, since they're invalid).
{
	if (!mIsOpen && !Open())
		// Since this should be very rare, a shorter message is now used.  Formerly, it was
		// "Could not open clipboard for writing after many timed attempts.  Another program is probably holding it open."
		return AbortWrite(CANT_OPEN_CLIPBOARD_WRITE);
	if (!EmptyClipboard())
	{
		Close();
		return AbortWrite(_T("EmptyClipboard")); // Short error message since so rare.
	}
	if (mClipMemNew)
	{
		bool new_is_empty = false;
		// Unlock prior to calling SetClipboardData:
		if (mClipMemNewLocked) // probably always true if we're here.
		{
			// Best to access the memory while it's still locked, which is why this temp var is used:
			// v1.0.40.02: The following was fixed to properly recognize 0x0000 as the Unicode string terminator,
			// which fixes problems with Transform Unicode.
			new_is_empty = aFormat == CF_UNICODETEXT ? !*(LPWSTR)mClipMemNewLocked : !*(LPSTR)mClipMemNewLocked;
			GlobalUnlock(mClipMemNew); // mClipMemNew not mClipMemNewLocked.
			mClipMemNewLocked = NULL;  // Keep this in sync with the above action.
			mCapacity = 0; // Keep mCapacity in sync with the state of mClipMemNewLocked.
		}
		if (new_is_empty)
			// Leave the clipboard truly empty rather than setting it to be the
			// empty string (i.e. these two conditions are NOT the same).
			// But be sure to free the memory since we're not giving custody
			// of it to the system:
			mClipMemNew = GlobalFree(mClipMemNew);
		else
			if (SetClipboardData(aFormat, mClipMemNew))
				// In any of the failure conditions above, Close() ensures that mClipMemNew is
				// freed if it was allocated.  But now that we're here, the memory should not be
				// freed because it is owned by the clipboard (it will free it at the appropriate time).
				// Thus, we relinquish the memory because we shouldn't be looking at it anymore:
				mClipMemNew = NULL;
			else
			{
				Close();
				return AbortWrite(_T("SetClipboardData")); // Short error message since so rare.
			}
	}
	// else we will close it after having done only the EmptyClipboard(), above.
	// Note: Decided not to update mLength for performance reasons (in case clipboard is huge).
	// Anyway, it seems rather pointless because once the clipboard is closed, our app instantly
	// loses sight of how large it is, so the the value of mLength wouldn't be reliable unless
	// the clipboard were going to be immediately opened again.
	return Close();
}



ResultType Clipboard::AbortWrite(LPTSTR aErrorMessage)
// Always returns FAIL.
{
	// Since we were called in conjunction with an aborted attempt to Commit(), always
	// ensure the clipboard is physically closed because even an attempt to Commit()
	// should physically close it:
	Close();
	if (mClipMemNewLocked)
	{
		GlobalUnlock(mClipMemNew); // mClipMemNew not mClipMemNewLocked.
		mClipMemNewLocked = NULL;
		mCapacity = 0; // Keep mCapacity in sync with the state of mClipMemNewLocked.
	}
	// Above: Unlock prior to freeing below.
	if (mClipMemNew)
		mClipMemNew = GlobalFree(mClipMemNew);
	// Caller needs us to always return FAIL:
	return *aErrorMessage ? g_script.RuntimeError(aErrorMessage) : FAIL;
}



ResultType Clipboard::Close(LPTSTR aErrorMessage)
// Returns OK or FAIL (but it only returns FAIL if caller gave us a non-NULL aErrorMessage).
{
	// Always close it ASAP so that it is free for other apps to use:
	if (mIsOpen)
	{
		if (mClipMemNowLocked)
		{
			GlobalUnlock(mClipMemNow); // mClipMemNow not mClipMemNowLocked.
			mClipMemNowLocked = NULL;  // Keep this in sync with its state, since it's used as an indicator.
		}
		// Above: It's probably best to unlock prior to closing the clipboard.
		CloseClipboard();
		mIsOpen = false;  // Even if above fails (realistically impossible?), seems best to do this.
		// Must do this only after GlobalUnlock():
		mClipMemNow = NULL;
	}
	// Do this cleanup for callers that didn't make it far enough to even open the clipboard.
	// UPDATE: DO *NOT* do this because it is valid to have the clipboard in a "ReadyForWrite"
	// state even after we physically close it.  Some callers rely on that.
	//if (mClipMemNewLocked)
	//{
	//	GlobalUnlock(mClipMemNew); // mClipMemNew not mClipMemNewLocked.
	//	mClipMemNewLocked = NULL;
	//	mCapacity = 0; // Keep mCapacity in sync with the state of mClipMemNewLocked.
	//}
	//// Above: Unlock prior to freeing below.
	//if (mClipMemNew)
	//	// Commit() was never called after a call to PrepareForWrite(), so just free the memory:
	//	mClipMemNew = GlobalFree(mClipMemNew);
	if (aErrorMessage && *aErrorMessage)
		// Caller needs us to always return FAIL if an error was displayed:
		return g_script.RuntimeError(aErrorMessage);

	// Seems best not to reset mLength.  But it will quickly become out of date once
	// the clipboard has been closed and other apps can use it.
	return OK;
}



HANDLE Clipboard::GetClipboardDataTimeout(UINT uFormat, BOOL *aNullIsOkay)
// Update for v1.1.16: The comments below are obsolete; search for "v1.1.16" for related comments.
// Same as GetClipboardData() except that it doesn't give up if the first call to GetClipboardData() fails.
// Instead, it continues to retry the operation for the number of milliseconds in g_ClipboardTimeout.
// This is necessary because GetClipboardData() has been observed to fail in repeatable situations (this
// is strange because our thread already has the clipboard locked open -- presumably it happens because the
// GetClipboardData() is unable to start a data stream from the application that actually serves up the data).
// If cases where the first call to GetClipboardData() fails, a subsequent call will often succeed if you give
// the owning application (such as Excel and Word) a little time to catch up.  This is especially necessary in
// the OnClipboardChange function, where sometimes a clipboard-change notification comes in before the owning
// app has finished preparing its data for subsequent readers of the clipboard.
{
#ifdef DEBUG_BY_LOGGING_CLIPBOARD_FORMATS  // Provides a convenient log of clipboard formats for analysis.
	static FILE *fp = fopen("c:\\debug_clipboard_formats.txt", "w");
#endif

	if (aNullIsOkay)
		*aNullIsOkay = FALSE; // Set default.

	TCHAR format_name[MAX_PATH + 1]; // MSDN's RegisterClipboardFormat() doesn't document any max length, but the ones we're interested in certainly don't exceed MAX_PATH.
	if (uFormat < 0xC000 || uFormat > 0xFFFF) // It's a registered format (you're supposed to verify in-range before calling GetClipboardFormatName()).  Also helps performance.
		*format_name = '\0'; // Don't need the name if it's a standard/CF_* format.
	else
	{
		// v1.0.42.04:
		// Probably need to call GetClipboardFormatName() rather than comparing directly to uFormat because
		// MSDN implies that OwnerLink and other registered formats might not always have the same ID under
		// all OSes (past and future).
		GetClipboardFormatName(uFormat, format_name, MAX_PATH);
		// Since RegisterClipboardFormat() is case insensitive, the case might vary.  So use stricmp() when
		// comparing format_name to anything.
		// "Link Source", "Link Source Descriptor" , and anything else starting with "Link Source" is likely
		// to be data that should not be attempted to be retrieved because:
		// 1) It causes unwanted bookmark effects in various versions of MS Word.
		// 2) Tests show that these formats are on the clipboard only if MS Word is open at the time
		//    ClipboardAll is accessed.  That implies they're transitory formats that aren't as essential
		//    or well suited to ClipboardAll as the other formats (but if it weren't for #1 above, this
		//    wouldn't be enough reason to omit it).
		// 3) Although there is hardly any documentation to be found at MSDN or elsewhere about these formats,
		//    it seems they're related to OLE, with further implications that the data is transitory.
		// Here are the formats that Word 2002 removes from the clipboard when it the app closes:
		// 0xC002 ObjectLink  >>> Causes WORD bookmarking problem.
		// 0xC003 OwnerLink
		// 0xC00D Link Source  >>> Causes WORD bookmarking problem.
		// 0xC00F Link Source Descriptor  >>> Doesn't directly cause bookmarking, but probably goes with above.
		// 0xC0DC Hyperlink
		if (   !_tcsnicmp(format_name, _T("Link Source"), 11) || !_tcsicmp(format_name, _T("ObjectLink"))
			|| !_tcsicmp(format_name, _T("OwnerLink"))
			// v1.0.44.07: The following were added to solve interference with MS Outlook's MS Word editor.
			// If a hotkey like ^F1::ClipboardSave:=ClipboardAll is pressed after pressing Ctrl-C in that
			// editor (perhaps only when copying HTML), two of the following error dialogs would otherwise
			// be displayed (this occurs in Outlook 2002 and probably later versions):
			// "An outgoing call cannot be made since the application is dispatching an input-synchronous call."
			|| !_tcsicmp(format_name, _T("Native")) || !_tcsicmp(format_name, _T("Embed Source"))   )
			return NULL;
		if (!_tcsicmp(format_name, _T("MSDEVColumnSelect")) || !_tcsicmp(format_name, _T("MSDEVLineSelect")))
		{
			// v1.1.16: These formats are used by Visual Studio, Scintilla controls and perhaps others for
			// copying whole lines and rectangular blocks.  Because their very presence/absence is used as
			// a boolean indicator, the data is irrelevant.  Presumably for this reason, Scintilla controls
			// set NULL data, though doing so and then not handling WM_RENDERFORMAT is probably invalid.
			// Note newer versions of Visual Studio use "VisualStudioEditorOperationsLineCutCopyClipboardTag"
			// for line copy, but that doesn't need to be handled here because it has non-NULL data (and the
			// latest unreleased Scintilla [as at 2014-08-19] uses both, so we can discard the long one).
			// Since we just want to preserve this format's presence, indicate to caller that NULL is okay:
			if (aNullIsOkay) // i.e. caller passed a variable for us to set.
				*aNullIsOkay = TRUE;
			return NULL;
		}
	}

#ifdef DEBUG_BY_LOGGING_CLIPBOARD_FORMATS
	_ftprintf(fp, _T("%04X\t%s\n"), uFormat, format_name);  // Since fclose() is never called, the program has to exit to close/release the file.
#endif

#ifndef ENABLE_CLIPBOARDGETDATA_TIMEOUT
	// v1.1.16: The timeout and retry behaviour of this function is currently disabled, since it does more
	// harm than good.  It previously did NO GOOD WHATSOEVER, because SLEEP_WITHOUT_INTERRUPTION indirectly
	// called g_clip.Close() via CLOSE_CLIPBOARD_IF_OPEN, so any subsequent attempts to retrieve data by us
	// or our caller always failed.  The main point of failure where retrying helps is OpenClipboard(), when
	// another program has the clipboard open -- and that's handled elsewhere.  If the timeout is re-enabled
	// for this function, the following format will need to be excluded to prevent unnecessary delays:
	//  - FileContents (CSTR_FILECONTENTS): MSDN says it is used "to transfer data as if it were a file,
	//    regardless of how it is actually stored".  For example, it could be a file inside a zip folder.
	//    However, on Windows 8 it seems to also be present for normal files.  It might be possible to
	//    retrieve its data via OleGetClipboard(), though it could be very large.

	// Just return the data, even if NULL:
	return GetClipboardData(uFormat);
#else
	HANDLE h;
	for (DWORD start_time = GetTickCount();;)
	{
		// Known failure conditions:
		// GetClipboardData() apparently fails when the text on the clipboard is greater than a certain size
		// (Even though GetLastError() reports "Operation completed successfully").  The data size at which
		// this occurs is somewhere between 20 to 96 MB (perhaps depending on system's memory and CPU speed).
		if (h = GetClipboardData(uFormat)) // Assign
			return h;

		// It failed, so act according to the type of format and the timeout that's in effect.
		// Certain standard (numerically constant) clipboard formats are known to validly yield NULL from a
		// call to GetClipboardData().  Never retry these because it would only cause unnecessary delays
		// (i.e. a failure until timeout).
		// v1.0.42.04: More importantly, retrying them appears to cause problems with saving a Word/Excel
		// clipboard via ClipboardAll.
		if (uFormat == CF_HDROP // This format can fail "normally" for the reasons described at "clipboard_contains_files".
			|| !_tcsicmp(format_name, _T("OwnerLink"))) // Known to validly yield NULL from a call to GetClipboardData(), so don't retry it to avoid having to wait the full timeout period.
			return NULL;

		if (g_ClipboardTimeout != -1) // We were not told to wait indefinitely and...
			if (!g_ClipboardTimeout   // ...we were told to make only one attempt, or ...
				|| (int)(g_ClipboardTimeout - (GetTickCount() - start_time)) <= SLEEP_INTERVAL_HALF) //...it timed out.
				// Above must cast to int or any negative result will be lost due to DWORD type.
				return NULL;

		// Use SLEEP_WITHOUT_INTERRUPTION to prevent MainWindowProc() from accepting new hotkeys
		// during our operation, since a new hotkey subroutine might interfere with
		// what we're doing here (e.g. if it tries to use the clipboard, or perhaps overwrites
		// the deref buffer if this object's caller gave it any pointers into that memory area):
		SLEEP_WITHOUT_INTERRUPTION(INTERVAL_UNSPECIFIED)
	}
#endif
}



ResultType Clipboard::Open()
{
	if (mIsOpen)
		return OK;
	for (DWORD start_time = GetTickCount();;)
	{
		if (OpenClipboard(g_hWnd))
		{
			mIsOpen = true;
			return OK;
		}
		if (g_ClipboardTimeout != -1) // We were not told to wait indefinitely...
			if (!g_ClipboardTimeout   // ...and we were told to make only one attempt, or ...
				|| (int)(g_ClipboardTimeout - (GetTickCount() - start_time)) <= SLEEP_INTERVAL_HALF) //...it timed out.
				// Above must cast to int or any negative result will be lost due to DWORD type.
				return FAIL;
		// Use SLEEP_WITHOUT_INTERRUPTION to prevent MainWindowProc() from accepting new hotkeys
		// during our operation, since a new hotkey subroutine might interfere with
		// what we're doing here (e.g. if it tries to use the clipboard, or perhaps overwrites
		// the deref buffer if this object's caller gave it any pointers into that memory area):
		SLEEP_WITHOUT_INTERRUPTION(INTERVAL_UNSPECIFIED)
	}
}
